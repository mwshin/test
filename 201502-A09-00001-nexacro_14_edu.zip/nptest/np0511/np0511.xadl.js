﻿(function()
{
    return function()
    {
        // Theme, Component URI Setting
        this._theme_uri = "./_theme_/";
        this._globalvar_uri = "globalvars.xml";
        this.loadTypedefition = function()
        {
            // this._addService(prefixid, type, url, cachelevel, codepage, language, version, communication);
            this._addService("default_typedef.xml", "Base", "form", "./Base/", "", null, "", "0", "0");
            this._addService("default_typedef.xml", "Work", "form", "./Work/", "", null, "", "", "0");
            this._addService("default_typedef.xml", "dataURL", "JSP", "http://demo.nexacro.com/edu/nexacro/", "", null, "", "", "0");
            this._addService("default_typedef.xml", "Images", "file", "./Images/", "", null, "", "", "0");
            this._addService("default_typedef.xml", "xlib", "js", "./xlib/", "", null, "", "", "0");

            this._component_uri = (this._arg_compurl ? this._arg_compurl : "./nexacro14lib/component/");
            // load components
            var registerclass = [
            		{"id":"Div", "classname":"nexacro.Div", "type":"JavaScript"},
            		{"id":"Button", "classname":"nexacro.Button", "type":"JavaScript"},
            		{"id":"PopupDiv", "classname":"nexacro.PopupDiv", "type":"JavaScript"},
            		{"id":"Combo", "classname":"nexacro.Combo", "type":"JavaScript"},
            		{"id":"CheckBox", "classname":"nexacro.CheckBox", "type":"JavaScript"},
            		{"id":"ListBox", "classname":"nexacro.ListBox", "type":"JavaScript"},
            		{"id":"Edit", "classname":"nexacro.Edit", "type":"JavaScript"},
            		{"id":"MaskEdit", "classname":"nexacro.MaskEdit", "type":"JavaScript"},
            		{"id":"TextArea", "classname":"nexacro.TextArea", "type":"JavaScript"},
            		{"id":"Menu", "classname":"nexacro.Menu", "type":"JavaScript"},
            		{"id":"Tab", "classname":"nexacro.Tab", "type":"JavaScript"},
            		{"id":"ImageViewer", "classname":"nexacro.ImageViewer", "type":"JavaScript"},
            		{"id":"Radio", "classname":"nexacro.Radio", "type":"JavaScript"},
            		{"id":"Calendar", "classname":"nexacro.Calendar", "type":"JavaScript"},
            		{"id":"Static", "classname":"nexacro.Static", "type":"JavaScript"},
            		{"id":"Grid", "classname":"nexacro.Grid", "type":"JavaScript"},
            		{"id":"Spin", "classname":"nexacro.Spin", "type":"JavaScript"},
            		{"id":"PopupMenu", "classname":"nexacro.PopupMenu", "type":"JavaScript"},
            		{"id":"GroupBox", "classname":"nexacro.GroupBox", "type":"JavaScript"},
            		{"id":"ProgressBar", "classname":"nexacro.ProgressBar", "type":"JavaScript"},
            		{"id":"Plugin", "classname":"nexacro.Plugin", "type":"JavaScript"},
            		{"id":"Dataset", "classname":"nexacro.NormalDataset", "type":"JavaScript"}
            ];
            this._addClasses(registerclass);
        };
        
        this.on_loadGlobalVariables = function()
        {
            // global variable

            // global image
            this._addImage("icecream", "Images::icecream.png");

            // global dataset
            var obj = null;
            obj = new Dataset("gds_menu", this);
            obj._setContents("<ColumnInfo><Column id=\"m_id\" type=\"STRING\" size=\"256\"/><Column id=\"m_nm\" type=\"STRING\" size=\"256\"/><Column id=\"m_lv\" type=\"STRING\" size=\"256\"/><Column id=\"m_ui\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"m_id\">1</Col><Col id=\"m_nm\">main1</Col><Col id=\"m_lv\">0</Col><Col id=\"m_ui\">[Undefined]</Col></Row><Row><Col id=\"m_id\">2</Col><Col id=\"m_nm\">sub1</Col><Col id=\"m_lv\">1</Col></Row><Row><Col id=\"m_id\">3</Col><Col id=\"m_nm\">hello</Col><Col id=\"m_lv\">2</Col><Col id=\"m_ui\">Work::Hello.xfdl</Col></Row><Row><Col id=\"m_id\">4</Col><Col id=\"m_nm\">emp</Col><Col id=\"m_lv\">2</Col><Col id=\"m_ui\">Work::Emp.xfdl</Col></Row><Row><Col id=\"m_id\">5</Col><Col id=\"m_nm\">main2</Col><Col id=\"m_lv\">0</Col></Row><Row><Col id=\"m_id\">6</Col><Col id=\"m_nm\">sub2</Col><Col id=\"m_lv\">1</Col></Row><Row><Col id=\"m_id\">7</Col><Col id=\"m_nm\">img</Col><Col id=\"m_lv\">2</Col><Col id=\"m_ui\">Work::Img.xfdl</Col></Row></Rows>");
            this._addDataset(obj.name, obj);
            obj = null;


            

        };
        
        // property, event, createMainFrame
        this.on_initApplication = function()
        {
            // properties
            this.set_id("np0511");
            this.set_version("");
            this.set_tracemode("none");
            this.set_themeid("default.xtheme");

            if (this._is_attach_childframe)
            	return;

            // frame
            var mainframe = this.createMainFrame("mainframe", "absolute", "0", "0", "800", "800", null, null, this);
            mainframe.set_resizable("true");
            mainframe.set_showtitlebar("true");
            mainframe.set_showstatusbar("true");
            mainframe.on_createBodyFrame = this.mainframe_createBodyFrame;

            // tray
            var tray = null;

        };
        

        
        this.mainframe_createBodyFrame = function()
        {
            var frame0 = new VFrameSet("VF", "absolute", null, null, null, null, null, null, this);
            this.addChild(frame0.name, frame0);
            this.frame = frame0;
            frame0.set_separatesize("100,*");

            
            var frame1 = new ChildFrame("CF0", "absolute", null, null, null, null, null, null, "Work::Top.xfdl", frame0);
            frame0.addChild(frame1.name, frame1);
            frame1.set_showtitlebar("false");
            frame1.set_showtitleicon("false");
            frame1.style.set_background("antiquewhite");
            frame1.set_formurl("Work::Top.xfdl");
            var frame2 = new HFrameSet("HF", "absolute", null, null, null, null, null, null, frame0);
            frame0.addChild(frame2.name, frame2);
            frame2.set_separatesize("200, *");

            
            var frame3 = new ChildFrame("CF1", "absolute", null, null, null, null, null, null, "Work::Left.xfdl", frame2);
            frame2.addChild(frame3.name, frame3);
            frame3.set_showtitlebar("false");
            frame3.set_showtitleicon("false");
            frame3.style.set_background("aquamarine");
            frame3.set_formurl("Work::Left.xfdl");
            var frame4 = new FrameSet("FS", "absolute", null, null, null, null, null, null, frame2);
            frame2.addChild(frame4.name, frame4);


        };
        
        this.on_initEvent = function()
        {

        };
        
        // screeninfo
        this.loadScreenInfo = function()
        {

        }
        
        // script Compiler
        this.registerScript("np0511.xadl", function(exports) {
        this.gfn_menu = function(sID,sUI)
        {
        	// FS 부모프레임
        	var objFS = application.mainframe.VF.HF.FS;
        	
        	// FS 에 CF 찾아서 Focus
        	var arrObj = objFS.all;
        	for(var i=0; i<arrObj.length; i++)
        	{
        		if(arrObj[i].name == sID)
        		{
        			arrObj[i].setFocus();
        			return;
        		}
        	}
        	
        	// CF 동적생성
        	var objCF = new ChildFrame();  
        	objCF.init(sID, "absolute", 0, 0, 800, 600, null, null, sUI);
        	objFS.addChild(sID, objCF); 
        	objCF.show();
        }
        
        });


        this.checkLicense("");
        this.loadTypedefition();
        this.loadScreenInfo();
        this.loadTheme("default.xtheme");


        this.loadIncludeScript("np0511.xadl", true);
    };
}
)();
