﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        this.on_create = function()
        {
            // Declare Reference
            var obj = null;
            
            if (Form == this.constructor) {
                this.set_name("Top");
                this.set_titletext("New Form");
                this._setFormPosition(0,0,1024,768);
            }

            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Menu("Menu00", "absolute", "10", "10", "600", "80", null, null, this);
            this.addChild(obj.name, obj);
            obj.set_taborder("0");
            obj.set_innerdataset("@gds_menu");
            obj.set_captioncolumn("m_nm");
            obj.set_idcolumn("m_id");
            obj.set_levelcolumn("m_lv");
            obj.set_userdatacolumn("m_ui");


            
            // Layout Functions
            //-- Default Layout
            obj = new Layout("default", "", 1024, 768, this,
            	//-- Layout function
            	function(p) {
            		p.set_titletext("New Form");

            	}
            );
            this.addLayout(obj.name, obj);


            
            // BindItem Information

            
            // Remove Reference
            obj = null;
        };
        

        
        // User Script
        this.addIncludeScript("Top.xfdl", "xlib::menu.xjs");
        this.registerScript("Top.xfdl", function(exports) {
        if (this.executeIncludeScript) { this.executeIncludeScript("xlib::menu.xjs", null, exports); }	//include "xlib::menu.xjs"
        this.Menu00_onmenuclick = function(obj,e)
        {
        	var sID = e.id;
        //	var sUI = e.userdata;
        	var sUI = application.gds_menu.lookup("m_id", sID, "m_ui");

        	//this.fn_menu(sID, sUI);
        	//application.gfn_menu(sID,sUI);
        	this.cfn_menu(sID, sUI);
        }

        this.fn_menu = function(sID,sUI)
        {
        	// FS 부모프레임
        	var objFS = application.mainframe.VF.HF.FS;
        	
        	// FS 에 CF 찾아서 Focus
        	var arrObj = objFS.all;
        	for(var i=0; i<arrObj.length; i++)
        	{
        		if(arrObj[i].name == sID)
        		{
        			arrObj[i].setFocus();
        			return;
        		}
        	}
        	
        	// CF 동적생성
        	var objCF = new ChildFrame();  
        	objCF.init(sID, "absolute", 0, 0, 800, 600, null, null, sUI);
        	objFS.addChild(sID, objCF); 
        	objCF.show();
        }
        
        });


        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Menu00.addEventHandler("onmenuclick", this.Menu00_onmenuclick, this);

        };

        this.loadIncludeScript("Top.xfdl", true);

       
    };
}
)();
