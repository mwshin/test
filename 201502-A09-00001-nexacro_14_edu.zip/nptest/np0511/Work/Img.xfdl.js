﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        this.on_create = function()
        {
            // Declare Reference
            var obj = null;
            
            if (Form == this.constructor) {
                this.set_name("Img");
                this.set_titletext("New Form");
                this._setFormPosition(0,0,1024,768);
            }

            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Static("Static00", "absolute", "64", "43", "180", "58", null, null, this);
            obj.set_taborder("0");
            obj.set_text("테마");
            obj.style.set_background("black");
            obj.style.set_color("aqua");
            obj.style.set_align("middle");
            obj.style.set_font("bold 16 Dotum,Arial Black");
            this.addChild(obj.name, obj);

            obj = new Static("Static01", "absolute", "320", "43", "180", "58", null, null, this);
            obj.set_taborder("1");
            obj.set_text("글로벌");
            obj.style.set_background("black");
            obj.style.set_color("aqua");
            obj.style.set_align("middle");
            obj.style.set_font("bold 16 Dotum,Arial Black");
            this.addChild(obj.name, obj);

            obj = new Static("Static02", "absolute", "583", "43", "180", "58", null, null, this);
            obj.set_taborder("2");
            obj.set_text("직접경로");
            obj.style.set_background("black");
            obj.style.set_color("aqua");
            obj.style.set_align("middle");
            obj.style.set_font("bold 16 Dotum,Arial Black");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer00", "absolute", "61", "117", "178", "191", null, null, this);
            obj.set_taborder("3");
            obj.set_text("ImageViewer00");
            obj.set_image("URL('theme://images/doughnut.png')");
            obj.set_stretch("fit");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer01", "absolute", "310", "121", "178", "191", null, null, this);
            obj.set_taborder("4");
            obj.set_text("ImageViewer00");
            obj.set_image("URL('icecream')");
            obj.set_stretch("fit");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer02", "absolute", "584", "120", "178", "191", null, null, this);
            obj.set_taborder("5");
            obj.set_text("ImageViewer00");
            obj.set_image("URL('Images::img_sample.png')");
            obj.set_stretch("fit");
            this.addChild(obj.name, obj);


            
            // Layout Functions
            //-- Default Layout
            obj = new Layout("default", "", 1024, 768, this,
            	//-- Layout function
            	function(p) {
            		p.set_titletext("New Form");

            	}
            );
            this.addLayout(obj.name, obj);


            
            // BindItem Information

            
            // Remove Reference
            obj = null;
        };
        

        
        // User Script
        this.registerScript("Img.xfdl", function(exports) {

        this.Static00_onclick = function(obj,e)
        {
        	
        }
        
        });


        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Static00.addEventHandler("onclick", this.Static00_onclick, this);
            this.Static01.addEventHandler("onclick", this.Static00_onclick, this);
            this.Static02.addEventHandler("onclick", this.Static00_onclick, this);

        };

        this.loadIncludeScript("Img.xfdl", true);

       
    };
}
)();
