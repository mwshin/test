﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        this.on_create = function()
        {
            // Declare Reference
            var obj = null;
            
            if (Form == this.constructor) {
                this.set_name("Emp");
                this.set_titletext("New Form");
                this._setFormPosition(0,0,1024,768);
            }

            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("ds_emp", this);
            obj._setContents("<ColumnInfo><Column id=\"EMPL_ID\" type=\"STRING\" size=\"5\"/><Column id=\"FULL_NAME\" type=\"STRING\" size=\"10\"/><Column id=\"DEPT_ID\" type=\"STRING\" size=\"2\"/><Column id=\"HIRE_DATE\" type=\"DATE\" size=\"8\"/><Column id=\"GENDER\" type=\"STRING\" size=\"1\"/><Column id=\"MARRIED\" type=\"STRING\" size=\"1\"/><Column id=\"SALARY\" type=\"INT\" size=\"10\"/><Column id=\"EMPL_MEMO\" type=\"STRING\" size=\"500\"/></ColumnInfo><Rows><Row><Col id=\"EMPL_ID\">AA001</Col><Col id=\"FULL_NAME\">ShinSoo Choo</Col><Col id=\"DEPT_ID\">01</Col><Col id=\"HIRE_DATE\">20011104</Col><Col id=\"GENDER\">M</Col><Col id=\"MARRIED\">1</Col><Col id=\"SALARY\">2000</Col><Col id=\"EMPL_MEMO\">Korean</Col></Row><Row><Col id=\"EMPL_ID\">BB001</Col><Col id=\"FULL_NAME\">Yuna Kim</Col><Col id=\"DEPT_ID\">02</Col><Col id=\"HIRE_DATE\">20050305</Col><Col id=\"GENDER\">W</Col><Col id=\"MARRIED\">0</Col><Col id=\"SALARY\">3000</Col><Col id=\"EMPL_MEMO\">Korean</Col></Row><Row><Col id=\"FULL_NAME\">Sumi Jo</Col><Col id=\"EMPL_ID\">CC001</Col><Col id=\"DEPT_ID\">03</Col><Col id=\"HIRE_DATE\">20100506</Col><Col id=\"GENDER\">W</Col><Col id=\"MARRIED\">0</Col><Col id=\"SALARY\">5000</Col><Col id=\"EMPL_MEMO\">Korean</Col></Row><Row><Col id=\"EMPL_ID\">DD001</Col><Col id=\"FULL_NAME\">JS Park</Col><Col id=\"DEPT_ID\">04</Col><Col id=\"HIRE_DATE\">20101123</Col><Col id=\"GENDER\">M</Col><Col id=\"MARRIED\">0</Col><Col id=\"SALARY\">3500</Col><Col id=\"EMPL_MEMO\">Korean</Col></Row></Rows>");
            this.addChild(obj.name, obj);

            obj = new Dataset("ds_dept", this);
            obj._setContents("<ColumnInfo><Column id=\"code\" type=\"STRING\" size=\"256\"/><Column id=\"name\" type=\"STRING\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"code\">01</Col><Col id=\"name\">총무부</Col></Row><Row><Col id=\"code\">02</Col><Col id=\"name\">개발부</Col></Row><Row><Col id=\"code\">03</Col><Col id=\"name\">인사부</Col></Row><Row><Col id=\"code\">04</Col><Col id=\"name\">교육부</Col></Row></Rows>");
            this.addChild(obj.name, obj);


            
            // UI Components Initialize
            obj = new Grid("Grid00", "absolute", "13", "93", "467", "427", null, null, this);
            obj.set_taborder("0");
            obj.set_binddataset("ds_emp");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"40\"/><Column size=\"40\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"40\"/><Column size=\"40\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"25\"/><Row size=\"24\" band=\"summ\"/></Rows><Band id=\"head\"><Cell text=\"NO\"/><Cell col=\"1\" text=\"TYPE\"/><Cell col=\"2\" text=\"EMPL_ID\"/><Cell col=\"3\" text=\"FULL_NAME\"/><Cell col=\"4\" text=\"DEPT_ID\"/><Cell col=\"5\" text=\"HIRE_DATE\"/><Cell col=\"6\" text=\"GENDER\"/><Cell col=\"7\" text=\"MARRIED\"/><Cell col=\"8\" text=\"SALARY\"/><Cell col=\"9\" text=\"EMPL_MEMO\"/><Cell col=\"10\"/><Cell col=\"11\"/></Band><Band id=\"body\"><Cell text=\"expr:currow +1\"/><Cell col=\"1\" text=\"expr:dataset.getRowType(currow)\"/><Cell col=\"2\" text=\"bind:FULL_NAME\" mask=\"AA-###\"/><Cell col=\"3\" style=\"color:EXPR(GENDER == &quot;M&quot; ? &quot;blue&quot; : &quot;red&quot;);color2:EXPR(GENDER == &quot;M&quot; ? &quot;blue&quot; : &quot;red&quot;);\" text=\"bind:FULL_NAME\"/><Cell col=\"4\" displaytype=\"combo\" edittype=\"combo\" text=\"bind:DEPT_ID\" combodataset=\"ds_dept\" combocodecol=\"code\" combodatacol=\"name\"/><Cell col=\"5\" text=\"bind:HIRE_DATE\"/><Cell col=\"6\" displaytype=\"normal\" edittype=\"none\" text=\"bind:GENDER\"/><Cell col=\"7\" displaytype=\"checkbox\" edittype=\"checkbox\" text=\"bind:MARRIED\"/><Cell col=\"8\" text=\"bind:SALARY\"/><Cell col=\"9\" text=\"bind:EMPL_MEMO\"/><Cell col=\"10\"/><Cell col=\"11\"/></Band><Band id=\"summary\"><Cell text=\"expr:comp.parent.ds_emp.getRowcount()\"/><Cell col=\"1\"/><Cell col=\"2\" text=\"expr:comp.parent.ds_emp.getRowCount()\"/><Cell col=\"3\" text=\"expr:dataset.getRowCount()\"/><Cell col=\"4\"/><Cell col=\"5\"/><Cell col=\"6\"/><Cell col=\"7\"/><Cell col=\"8\" text=\"expr:dataset.getSum('SALARY')\"/><Cell col=\"9\"/><Cell col=\"10\"/><Cell col=\"11\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Div("Div00", "absolute", "496", "93", "364", "521", null, null, this);
            obj.set_taborder("1");
            obj.set_text("Div00");
            obj.style.set_background("#0000000c");
            obj.style.set_color("#444444ff");
            this.addChild(obj.name, obj);
            obj = new Static("Static00", "absolute", "10", "10", "100", "35", null, null, this.Div00);
            obj.set_taborder("0");
            obj.set_text("ID");
            obj.set_cssclass("val_chk");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static01", "absolute", "10", "71", "100", "35", null, null, this.Div00);
            obj.set_taborder("1");
            obj.set_text("NAME");
            obj.set_cssclass("val_chk");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static02", "absolute", "10", "132", "100", "35", null, null, this.Div00);
            obj.set_taborder("2");
            obj.set_text("DEPT");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static03", "absolute", "10", "193", "100", "35", null, null, this.Div00);
            obj.set_taborder("3");
            obj.set_text("DATA");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static04", "absolute", "10", "254", "100", "35", null, null, this.Div00);
            obj.set_taborder("4");
            obj.set_text("GENDER");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static05", "absolute", "10", "315", "100", "35", null, null, this.Div00);
            obj.set_taborder("5");
            obj.set_text("MARRIED");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static08", "absolute", "8", "430", "100", "35", null, null, this.Div00);
            obj.set_taborder("8");
            obj.set_text("MARRIED");
            this.Div00.addChild(obj.name, obj);
            obj = new Static("Static09", "absolute", "10", "363", "100", "35", null, null, this.Div00);
            obj.set_taborder("9");
            obj.set_text("SALARY");
            this.Div00.addChild(obj.name, obj);
            obj = new Edit("Edit01", "absolute", "124", "73", "170", "40", null, null, this.Div00);
            obj.set_taborder("11");
            obj.style.set_align("right middle");
            this.Div00.addChild(obj.name, obj);
            obj = new MaskEdit("MaskEdit00", "absolute", "125", "14", "170", "40", null, null, this.Div00);
            obj.set_taborder("13");
            obj.set_mask("AA-###");
            obj.set_limitbymask("decimal");
            obj.set_type("string");
            this.Div00.addChild(obj.name, obj);
            obj = new Calendar("Calendar00", "absolute", "126", "195", "170", "39", null, null, this.Div00);
            this.Div00.addChild(obj.name, obj);
            obj.set_taborder("15");
            obj = new Radio("Radio00", "absolute", "122", "254", "170", "34", null, null, this.Div00);
            this.Div00.addChild(obj.name, obj);
            var Radio00_innerdataset = new Dataset("Radio00_innerdataset", this.Div00.Radio00);
            Radio00_innerdataset._setContents("<ColumnInfo><Column id=\"codecolumn\" size=\"256\"/><Column id=\"datacolumn\" size=\"256\"/></ColumnInfo><Rows><Row><Col id=\"codecolumn\">M</Col><Col id=\"datacolumn\">남</Col></Row><Row><Col id=\"codecolumn\">W</Col><Col id=\"datacolumn\">여</Col></Row><Row><Col id=\"codecolumn\">9</Col><Col id=\"datacolumn\">기타</Col></Row></Rows>");
            obj.set_innerdataset(Radio00_innerdataset);
            obj.set_taborder("16");
            obj.set_codecolumn("codecolumn");
            obj.set_datacolumn("datacolumn");
            obj.set_columncount("0");
            obj.set_rowcount("1");
            obj = new CheckBox("CheckBox00", "absolute", "125", "306", "170", "37", null, null, this.Div00);
            obj.set_taborder("17");
            this.Div00.addChild(obj.name, obj);
            obj = new MaskEdit("MaskEdit01", "absolute", "125", "366", "170", "31", null, null, this.Div00);
            obj.set_taborder("18");
            obj.set_mask("#,###");
            this.Div00.addChild(obj.name, obj);
            obj = new Calendar("Calendar01", "absolute", "145", "307", "150", "35", null, null, this.Div00);
            this.Div00.addChild(obj.name, obj);
            obj.set_taborder("21");
            obj = new Combo("dropbutton", "absolute", "127", "126", "167", "42", null, null, this.Div00);
            this.Div00.addChild(obj.name, obj);
            obj.set_taborder("22");
            obj.set_text("Combo00");
            obj.set_innerdataset("@ds_dept");
            obj.set_datacolumn("name");
            obj.set_codecolumn("code");

            obj = new TextArea("TextArea00", "absolute", "619", "430", "170", "60", null, null, this);
            obj.set_taborder("2");
            this.addChild(obj.name, obj);

            obj = new Button("btn_select", "absolute", "344", "30", "120", "50", null, null, this);
            obj.set_taborder("3");
            obj.set_text("조회");
            this.addChild(obj.name, obj);

            obj = new Button("btn_add", "absolute", "472", "29", "120", "50", null, null, this);
            obj.set_taborder("4");
            obj.set_text("입력");
            this.addChild(obj.name, obj);

            obj = new Button("btn_delete", "absolute", "604", "30", "120", "50", null, null, this);
            obj.set_taborder("5");
            obj.set_text("삭제");
            this.addChild(obj.name, obj);

            obj = new Button("btn_save", "absolute", "736", "29", "120", "50", null, null, this);
            obj.set_taborder("6");
            obj.set_text("저장");
            this.addChild(obj.name, obj);

            obj = new Static("st_title", "absolute", "28", "30", "167", "35", null, null, this);
            obj.set_taborder("7");
            this.addChild(obj.name, obj);


            
            // Layout Functions
            //-- Default Layout
            obj = new Layout("default", "", 287, 253, this.Div00,
            	//-- Layout function
            	function(p) {
            		p.set_taborder("1");
            		p.set_text("Div00");
            		p.style.set_background("#0000000c");
            		p.style.set_color("#444444ff");

            	}
            );
            this.Div00.addLayout(obj.name, obj);

            //-- Default Layout
            obj = new Layout("default", "", 1024, 768, this,
            	//-- Layout function
            	function(p) {
            		p.set_titletext("New Form");

            	}
            );
            this.addLayout(obj.name, obj);


            
            // BindItem Information
            obj = new BindItem("item1","Div00.Edit01","value","ds_emp","FULL_NAME");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item0","Div00.MaskEdit00","value","ds_emp","EMPL_ID");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item2","Div00.Edit01","","ds_emp","FULL_NAME");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item3","Div00.MaskEdit00","mask","ds_emp","EMPL_ID");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item5","Div00.CheckBox00","value","ds_emp","MARRIED");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item6","Div00.MaskEdit01","value","ds_emp","SALARY");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item7","TextArea00","value","ds_emp","MARRIED");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item8","Div00.Radio00","value","ds_emp","GENDER");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item9","Div00.Calendar01","visible","ds_emp","MARRIED");
            this.addChild(obj.name, obj);
            obj.bind();
            obj = new BindItem("item4","Div00.dropbutton","value","ds_emp","DEPT_ID");
            this.addChild(obj.name, obj);
            obj.bind();

            
            // Remove Reference
            obj = null;
        };
        

        
        // User Script
        this.registerScript("Emp.xfdl", function(exports) {

        this.btn_select_onclick = function(obj,e)
        {
        	this.transaction(
        		"tr_select "// 1.id
        		,"dataURL::employees_select.jsp"// 2.URL
        		,""// 3.Inds - I, U, D
        		,"ds_emp=ds_employees"// 4.OutDs - SELECT 
        		,""// 5.InVar - 
        		,"fn_callback"// 6.callback
        	);
        }
        this.out_var = "";
        this.fn_callback = function(id,nCode,msg) 
        {
        	if(nCode < 0 ) {
        		this.alert("fail");
        		return ;
        	}
        	this.alert(id + "succ : " + this.ds_emp.getRowCount() + this.out_var) ;
        }

        this.btn_add_onclick = function(obj,e)
        {
        	this.ds_emp.addRow();
        }

        this.btn_delete_onclick = function(obj,e)
        {
        		this.ds_emp.deleteRow(this.ds_emp.rowposition);
        }

        this.btn_save_onclick = function(obj,e)
        {
        	var name = "신민우";
        	
        	this.transaction(
        		"tr_save "// 1.id
        		,"dataURL::employees_save.jsp"// 2.URL
        		,"in_ds=ds_emp:U"// 3.Inds - I, U, D
        		,""// 4.OutDs - SELECT 
        		,"sVal1="+nexacro.wrapQuote(name)// 5.InVar - 
        		,"fn_callback"// 6.callback
        	);
        }
        
        });


        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Div00.Static00.addEventHandler("onclick", this.Div00_Static00_onclick, this);
            this.Div00.CheckBox00.addEventHandler("onclick", this.Div00_CheckBox00_onclick, this);
            this.btn_select.addEventHandler("onclick", this.btn_select_onclick, this);
            this.btn_add.addEventHandler("onclick", this.btn_add_onclick, this);
            this.btn_delete.addEventHandler("onclick", this.btn_delete_onclick, this);
            this.btn_save.addEventHandler("onclick", this.btn_save_onclick, this);

        };
        this.loadCss("Work::myCss.css");

        this.loadIncludeScript("Emp.xfdl", true);

       
    };
}
)();
