﻿(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        this.on_create = function()
        {
            // Declare Reference
            var obj = null;
            
            if (Form == this.constructor) {
                this.set_name("Hello");
                this.set_titletext("New Form");
                this._setFormPosition(0,0,1024,768);
            }

            
            // Object(Dataset, ExcelExportObject) Initialize

            
            // UI Components Initialize
            obj = new Button("Button00", "absolute", "64", "30", "120", "50", null, null, this);
            obj.set_taborder("0");
            obj.set_text("Button00");
            obj.style.set_color("black");
            this.addChild(obj.name, obj);

            obj = new Button("Button01", "absolute", "769", "52", "120", "50", null, null, this);
            obj.set_taborder("1");
            obj.set_text("Button01");
            this.addChild(obj.name, obj);


            
            // Layout Functions
            //-- Default Layout
            obj = new Layout("default", "", 1024, 768, this,
            	//-- Layout function
            	function(p) {
            		p.set_titletext("New Form");

            	}
            );
            this.addLayout(obj.name, obj);


            
            // BindItem Information

            
            // Remove Reference
            obj = null;
        };
        

        
        // User Script
        this.registerScript("Hello.xfdl", function(exports) {

        this.Button00_onclick = function(obj,e)
        {
        	//this.alert("Hello");
        	//application.trace("Hello2");
        	
        	obj.set_text("btn_hello");
        	obj.style.set_background("red");
        	this.alert(obj.text);
        	
        	nexacro.round(34.7890, 2);
        	Math.round(34.7890)
        ;}

        this.fn_click = function(obj,e)
        {
        	
        }

        this.Button01_onclick = function(obj,e)
        {
        	
        }
        
        });


        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick", this.Button00_onclick, this);
            this.Button01.addEventHandler("onclick", this.Button00_onclick, this);

        };

        this.loadIncludeScript("Hello.xfdl", true);

       
    };
}
)();
