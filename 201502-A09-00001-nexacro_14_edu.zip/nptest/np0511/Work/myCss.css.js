﻿//CSS=myCss.css
    
(function() {
  return function() {
    var obj;   
    
    obj = new nexacro.Style_background("#dc143c32","","","0","0","0","0","true");
    this._addCss("Static", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#dc143c81","","","0","0","0","0","true");
    this._addCss("Static", "background", obj, ["mouseover"]);

    obj = new nexacro.Style_background("#ff0000ff","","","0","0","0","0","true");
    this._addCss("#st_title", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#dda0ddff","","","0","0","0","0","true");
    this._addCss("Static.val_chk", "background", obj, ["normal"]);

    obj = new nexacro.Style_background("#ff1493ff","","","0","0","0","0","true");
    this._addCss("Combo>#dropbutton", "background", obj, ["normal"]);

    obj = null;
    
//[add theme images]
  };
})();
